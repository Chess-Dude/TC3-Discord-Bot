class FailedToUnderstandGuidelines(Exception):
    pass

class NotFree(Exception):
    pass
