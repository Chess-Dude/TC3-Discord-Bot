class InvalidPrizeType(Exception):
    pass
